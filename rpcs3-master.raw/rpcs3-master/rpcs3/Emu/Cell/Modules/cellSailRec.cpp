#include "stdafx.h"
#include "Emu/Cell/PPUModule.h"

LOG_CHANNEL(cellSailRec);

error_code cellSailProfileSetEsAudioParameter()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailProfileSetEsVideoParameter()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailProfileSetStreamParameter()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailVideoConverterCanProcess()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailVideoConverterProcess()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailVideoConverterCanGetResult()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailVideoConverterGetResult()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailFeederAudioInitialize()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailFeederAudioFinalize()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailFeederAudioNotifyCallCompleted()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailFeederAudioNotifyFrameOut()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailFeederAudioNotifySessionEnd()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailFeederAudioNotifySessionError()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailFeederVideoInitialize()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailFeederVideoFinalize()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailFeederVideoNotifyCallCompleted()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailFeederVideoNotifyFrameOut()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailFeederVideoNotifySessionEnd()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailFeederVideoNotifySessionError()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailRecorderInitialize()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailRecorderFinalize()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailRecorderSetFeederAudio()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailRecorderSetFeederVideo()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailRecorderSetParameter()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailRecorderGetParameter()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailRecorderSubscribeEvent()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailRecorderUnsubscribeEvent()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailRecorderReplaceEventHandler()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailRecorderBoot()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailRecorderCreateProfile()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailRecorderDestroyProfile()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailRecorderCreateVideoConverter()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailRecorderDestroyVideoConverter()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailRecorderOpenStream()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailRecorderCloseStream()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailRecorderStart()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailRecorderStop()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailRecorderCancel()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailRecorderRegisterComposer()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailRecorderUnregisterComposer()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailRecorderDumpImage()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailComposerInitialize()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailComposerFinalize()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailComposerGetStreamParameter()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailComposerGetEsAudioParameter()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailComposerGetEsUserParameter()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailComposerGetEsVideoParameter()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailComposerGetEsAudioAu()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailComposerGetEsUserAu()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailComposerGetEsVideoAu()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailComposerTryGetEsAudioAu()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailComposerTryGetEsUserAu()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailComposerTryGetEsVideoAu()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailComposerReleaseEsAudioAu()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailComposerReleaseEsUserAu()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailComposerReleaseEsVideoAu()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailComposerNotifyCallCompleted()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

error_code cellSailComposerNotifySessionError()
{
	UNIMPLEMENTED_FUNC(cellSailRec);
	return CELL_OK;
}

DECLARE(ppu_module_manager::cellSailRec)("cellSailRec", []()
{
	static ppu_static_module cellMp4("cellMp4");
	static ppu_static_module cellApostSrcMini("cellApostSrcMini");

	REG_FUNC(cellSailRec, cellSailProfileSetEsAudioParameter);
	REG_FUNC(cellSailRec, cellSailProfileSetEsVideoParameter);
	REG_FUNC(cellSailRec, cellSailProfileSetStreamParameter);

	REG_FUNC(cellSailRec, cellSailVideoConverterCanProcess);
	REG_FUNC(cellSailRec, cellSailVideoConverterProcess);
	REG_FUNC(cellSailRec, cellSailVideoConverterCanGetResult);
	REG_FUNC(cellSailRec, cellSailVideoConverterGetResult);

	REG_FUNC(cellSailRec, cellSailFeederAudioInitialize);
	REG_FUNC(cellSailRec, cellSailFeederAudioFinalize);
	REG_FUNC(cellSailRec, cellSailFeederAudioNotifyCallCompleted);
	REG_FUNC(cellSailRec, cellSailFeederAudioNotifyFrameOut);
	REG_FUNC(cellSailRec, cellSailFeederAudioNotifySessionEnd);
	REG_FUNC(cellSailRec, cellSailFeederAudioNotifySessionError);

	REG_FUNC(cellSailRec, cellSailFeederVideoInitialize);
	REG_FUNC(cellSailRec, cellSailFeederVideoFinalize);
	REG_FUNC(cellSailRec, cellSailFeederVideoNotifyCallCompleted);
	REG_FUNC(cellSailRec, cellSailFeederVideoNotifyFrameOut);
	REG_FUNC(cellSailRec, cellSailFeederVideoNotifySessionEnd);
	REG_FUNC(cellSailRec, cellSailFeederVideoNotifySessionError);

	REG_FUNC(cellSailRec, cellSailRecorderInitialize);
	REG_FUNC(cellSailRec, cellSailRecorderFinalize);
	REG_FUNC(cellSailRec, cellSailRecorderSetFeederAudio);
	REG_FUNC(cellSailRec, cellSailRecorderSetFeederVideo);
	REG_FUNC(cellSailRec, cellSailRecorderSetParameter);
	REG_FUNC(cellSailRec, cellSailRecorderGetParameter);
	REG_FUNC(cellSailRec, cellSailRecorderSubscribeEvent);
	REG_FUNC(cellSailRec, cellSailRecorderUnsubscribeEvent);
	REG_FUNC(cellSailRec, cellSailRecorderReplaceEventHandler);
	REG_FUNC(cellSailRec, cellSailRecorderBoot);
	REG_FUNC(cellSailRec, cellSailRecorderCreateProfile);
	REG_FUNC(cellSailRec, cellSailRecorderDestroyProfile);
	REG_FUNC(cellSailRec, cellSailRecorderCreateVideoConverter);
	REG_FUNC(cellSailRec, cellSailRecorderDestroyVideoConverter);
	REG_FUNC(cellSailRec, cellSailRecorderOpenStream);
	REG_FUNC(cellSailRec, cellSailRecorderCloseStream);
	REG_FUNC(cellSailRec, cellSailRecorderStart);
	REG_FUNC(cellSailRec, cellSailRecorderStop);
	REG_FUNC(cellSailRec, cellSailRecorderCancel);
	REG_FUNC(cellSailRec, cellSailRecorderRegisterComposer);
	REG_FUNC(cellSailRec, cellSailRecorderUnregisterComposer);

	REG_FUNC(cellSailRec, cellSailRecorderDumpImage);

	REG_FUNC(cellSailRec, cellSailComposerInitialize);
	REG_FUNC(cellSailRec, cellSailComposerFinalize);
	REG_FUNC(cellSailRec, cellSailComposerGetStreamParameter);
	REG_FUNC(cellSailRec, cellSailComposerGetEsAudioParameter);
	REG_FUNC(cellSailRec, cellSailComposerGetEsUserParameter);
	REG_FUNC(cellSailRec, cellSailComposerGetEsVideoParameter);
	REG_FUNC(cellSailRec, cellSailComposerGetEsAudioAu);
	REG_FUNC(cellSailRec, cellSailComposerGetEsUserAu);
	REG_FUNC(cellSailRec, cellSailComposerGetEsVideoAu);
	REG_FUNC(cellSailRec, cellSailComposerTryGetEsAudioAu);
	REG_FUNC(cellSailRec, cellSailComposerTryGetEsUserAu);
	REG_FUNC(cellSailRec, cellSailComposerTryGetEsVideoAu);
	REG_FUNC(cellSailRec, cellSailComposerReleaseEsAudioAu);
	REG_FUNC(cellSailRec, cellSailComposerReleaseEsUserAu);
	REG_FUNC(cellSailRec, cellSailComposerReleaseEsVideoAu);
	REG_FUNC(cellSailRec, cellSailComposerNotifyCallCompleted);
	REG_FUNC(cellSailRec, cellSailComposerNotifySessionError);
});
