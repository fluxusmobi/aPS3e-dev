#include "stdafx.h"
#include "Emu/Cell/PPUModule.h"

LOG_CHANNEL(cellSpursJq);

error_code cellSpursJobQueueAttributeInitialize()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code cellSpursJobQueueAttributeSetMaxGrab()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code cellSpursJobQueueAttributeSetSubmitWithEntryLock()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code cellSpursJobQueueAttributeSetDoBusyWaiting()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code cellSpursJobQueueAttributeSetIsHaltOnError()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code cellSpursJobQueueAttributeSetIsJobTypeMemoryCheck()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code cellSpursJobQueueAttributeSetMaxSizeJobDescriptor()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code cellSpursJobQueueAttributeSetGrabParameters()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code cellSpursJobQueueSetWaitingMode()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code cellSpursShutdownJobQueue()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code _cellSpursCreateJobQueueWithJobDescriptorPool()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code _cellSpursCreateJobQueue()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code cellSpursJoinJobQueue()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code _cellSpursJobQueuePushJobListBody()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code _cellSpursJobQueuePushJobBody2()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code _cellSpursJobQueuePushJob2Body()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code _cellSpursJobQueuePushAndReleaseJobBody()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code _cellSpursJobQueuePushJobBody()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code _cellSpursJobQueuePushBody()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code _cellSpursJobQueueAllocateJobDescriptorBody()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code _cellSpursJobQueuePushSync()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code _cellSpursJobQueuePushFlush()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code cellSpursJobQueueGetSpurs()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code cellSpursJobQueueGetHandleCount()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code cellSpursJobQueueGetError()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code cellSpursJobQueueGetMaxSizeJobDescriptor()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code cellSpursGetJobQueueId()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code cellSpursJobQueueGetSuspendedJobSize()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code cellSpursJobQueueClose()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code cellSpursJobQueueOpen()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code cellSpursJobQueueSemaphoreTryAcquire()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code cellSpursJobQueueSemaphoreAcquire()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code cellSpursJobQueueSemaphoreInitialize()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code cellSpursJobQueueSendSignal()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code cellSpursJobQueuePortGetJobQueue()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code _cellSpursJobQueuePortPushSync()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code _cellSpursJobQueuePortPushFlush()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code _cellSpursJobQueuePortPushJobListBody()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code _cellSpursJobQueuePortPushJobBody()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code _cellSpursJobQueuePortPushJobBody2()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code _cellSpursJobQueuePortPushBody()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code cellSpursJobQueuePortTrySync()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code cellSpursJobQueuePortSync()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code cellSpursJobQueuePortInitialize()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code cellSpursJobQueuePortInitializeWithDescriptorBuffer()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code cellSpursJobQueuePortFinalize()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code _cellSpursJobQueuePortCopyPushJobBody()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code _cellSpursJobQueuePortCopyPushJobBody2()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code _cellSpursJobQueuePortCopyPushBody()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code cellSpursJobQueuePort2GetJobQueue()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code cellSpursJobQueuePort2PushSync()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code cellSpursJobQueuePort2PushFlush()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code _cellSpursJobQueuePort2PushJobListBody()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code cellSpursJobQueuePort2Sync()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code cellSpursJobQueuePort2Create()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code cellSpursJobQueuePort2Destroy()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code cellSpursJobQueuePort2AllocateJobDescriptor()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code _cellSpursJobQueuePort2PushAndReleaseJobBody()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code _cellSpursJobQueuePort2CopyPushJobBody()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code _cellSpursJobQueuePort2PushJobBody()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code cellSpursJobQueueSetExceptionEventHandler()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code cellSpursJobQueueSetExceptionEventHandler2()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

error_code cellSpursJobQueueUnsetExceptionEventHandler()
{
	UNIMPLEMENTED_FUNC(cellSpursJq);
	return CELL_OK;
}

DECLARE(ppu_module_manager::cellSpursJq)("cellSpursJq", []()
{
	REG_FUNC(cellSpursJq, cellSpursJobQueueAttributeInitialize);
	REG_FUNC(cellSpursJq, cellSpursJobQueueAttributeSetMaxGrab);
	REG_FUNC(cellSpursJq, cellSpursJobQueueAttributeSetSubmitWithEntryLock);
	REG_FUNC(cellSpursJq, cellSpursJobQueueAttributeSetDoBusyWaiting);
	REG_FUNC(cellSpursJq, cellSpursJobQueueAttributeSetIsHaltOnError);
	REG_FUNC(cellSpursJq, cellSpursJobQueueAttributeSetIsJobTypeMemoryCheck);
	REG_FUNC(cellSpursJq, cellSpursJobQueueAttributeSetMaxSizeJobDescriptor);
	REG_FUNC(cellSpursJq, cellSpursJobQueueAttributeSetGrabParameters);
	REG_FUNC(cellSpursJq, cellSpursJobQueueSetWaitingMode);
	REG_FUNC(cellSpursJq, cellSpursShutdownJobQueue);
	REG_FUNC(cellSpursJq, _cellSpursCreateJobQueueWithJobDescriptorPool);
	REG_FUNC(cellSpursJq, _cellSpursCreateJobQueue);
	REG_FUNC(cellSpursJq, cellSpursJoinJobQueue);
	REG_FUNC(cellSpursJq, _cellSpursJobQueuePushJobListBody);
	REG_FUNC(cellSpursJq, _cellSpursJobQueuePushJobBody2);
	REG_FUNC(cellSpursJq, _cellSpursJobQueuePushJob2Body);
	REG_FUNC(cellSpursJq, _cellSpursJobQueuePushAndReleaseJobBody);
	REG_FUNC(cellSpursJq, _cellSpursJobQueuePushJobBody);
	REG_FUNC(cellSpursJq, _cellSpursJobQueuePushBody);
	REG_FUNC(cellSpursJq, _cellSpursJobQueueAllocateJobDescriptorBody);
	REG_FUNC(cellSpursJq, _cellSpursJobQueuePushSync);
	REG_FUNC(cellSpursJq, _cellSpursJobQueuePushFlush);
	REG_FUNC(cellSpursJq, cellSpursJobQueueGetSpurs);
	REG_FUNC(cellSpursJq, cellSpursJobQueueGetHandleCount);
	REG_FUNC(cellSpursJq, cellSpursJobQueueGetError);
	REG_FUNC(cellSpursJq, cellSpursJobQueueGetMaxSizeJobDescriptor);
	REG_FUNC(cellSpursJq, cellSpursGetJobQueueId);
	REG_FUNC(cellSpursJq, cellSpursJobQueueGetSuspendedJobSize);
	REG_FUNC(cellSpursJq, cellSpursJobQueueClose);
	REG_FUNC(cellSpursJq, cellSpursJobQueueOpen);
	REG_FUNC(cellSpursJq, cellSpursJobQueueSemaphoreTryAcquire);
	REG_FUNC(cellSpursJq, cellSpursJobQueueSemaphoreAcquire);
	REG_FUNC(cellSpursJq, cellSpursJobQueueSemaphoreInitialize);
	REG_FUNC(cellSpursJq, cellSpursJobQueueSendSignal);
	REG_FUNC(cellSpursJq, cellSpursJobQueuePortGetJobQueue);
	REG_FUNC(cellSpursJq, _cellSpursJobQueuePortPushSync);
	REG_FUNC(cellSpursJq, _cellSpursJobQueuePortPushFlush);
	REG_FUNC(cellSpursJq, _cellSpursJobQueuePortPushJobListBody);
	REG_FUNC(cellSpursJq, _cellSpursJobQueuePortPushJobBody);
	REG_FUNC(cellSpursJq, _cellSpursJobQueuePortPushJobBody2);
	REG_FUNC(cellSpursJq, _cellSpursJobQueuePortPushBody);
	REG_FUNC(cellSpursJq, cellSpursJobQueuePortTrySync);
	REG_FUNC(cellSpursJq, cellSpursJobQueuePortSync);
	REG_FUNC(cellSpursJq, cellSpursJobQueuePortInitialize);
	REG_FUNC(cellSpursJq, cellSpursJobQueuePortInitializeWithDescriptorBuffer);
	REG_FUNC(cellSpursJq, cellSpursJobQueuePortFinalize);
	REG_FUNC(cellSpursJq, _cellSpursJobQueuePortCopyPushJobBody);
	REG_FUNC(cellSpursJq, _cellSpursJobQueuePortCopyPushJobBody2);
	REG_FUNC(cellSpursJq, _cellSpursJobQueuePortCopyPushBody);
	REG_FUNC(cellSpursJq, cellSpursJobQueuePort2GetJobQueue);
	REG_FUNC(cellSpursJq, cellSpursJobQueuePort2PushSync);
	REG_FUNC(cellSpursJq, cellSpursJobQueuePort2PushFlush);
	REG_FUNC(cellSpursJq, _cellSpursJobQueuePort2PushJobListBody);
	REG_FUNC(cellSpursJq, cellSpursJobQueuePort2Sync);
	REG_FUNC(cellSpursJq, cellSpursJobQueuePort2Create);
	REG_FUNC(cellSpursJq, cellSpursJobQueuePort2Destroy);
	REG_FUNC(cellSpursJq, cellSpursJobQueuePort2AllocateJobDescriptor);
	REG_FUNC(cellSpursJq, _cellSpursJobQueuePort2PushAndReleaseJobBody);
	REG_FUNC(cellSpursJq, _cellSpursJobQueuePort2CopyPushJobBody);
	REG_FUNC(cellSpursJq, _cellSpursJobQueuePort2PushJobBody);
	REG_FUNC(cellSpursJq, cellSpursJobQueueSetExceptionEventHandler);
	REG_FUNC(cellSpursJq, cellSpursJobQueueSetExceptionEventHandler2);
	REG_FUNC(cellSpursJq, cellSpursJobQueueUnsetExceptionEventHandler);
});
