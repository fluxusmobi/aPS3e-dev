#pragma once

error_code sceNpManagerIsSP();
